package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Customer_Service : AppCompatActivity() {
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_service)

        // back btn declare
        backButton = findViewById(R.id.button3)

        backButton.setOnClickListener {
            // back to Homepage
            val intent = Intent(this, Homepage::class.java)
            startActivity(intent)
            finish()
        }
    }
}